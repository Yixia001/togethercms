##### Sasson - Advanced Drupal Theming. #####

This is the directory for all your image files.
