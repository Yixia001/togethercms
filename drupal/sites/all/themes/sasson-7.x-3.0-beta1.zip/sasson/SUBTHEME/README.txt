##### Sasson - Advanced Drupal Theming. #####

This is the root of your sub-theme.

It must contains your .info file in which you may edit many important
settings like base theme, theme regions and additional style sheets and
script files (http://drupal.org/node/171205).

Check out your theme settings page for layout settings, development settings, Sass settings and more.

Much more info on Sasson's README.txt
