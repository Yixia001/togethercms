/*
 * #############################################
 * ##### Sasson - Advanced Drupal Theming. #####
 * #############################################
 *
 *           Starterkit main script.
 */

(function($) {

  // DUPLICATE AND UNCOMMENT
  // Drupal.behaviors.behaviorName = {
  //   attach: function (context, settings) {
  //     // Do some magic...
  //   }
  // };

})(jQuery);
